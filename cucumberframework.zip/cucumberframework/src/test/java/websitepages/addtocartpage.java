package websitepages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import seleniumexecution.selenumsteps;

public class addtocartpage {
	
	@FindBy(xpath="//*[@id=\"homefeatured\"]/li[2]/div/div[1]/div/a[1]/img")
	WebElement itemimage;
	@FindBy(xpath="//*[@id=\"homefeatured\"]/li[2]/div/div[2]/div[2]/a[2]")
    WebElement btnmore;
	@FindBy(xpath="//*[@id=\"quantity_wanted\"]")
	WebElement quantity;
	@FindBy(xpath="//*[@id=\"group_1\"]")
	WebElement size;
	@FindBy(xpath="//*[@id=\"add_to_cart\"]/button")
	WebElement addtocartbtn;
	@FindBy(css="div#layer_cart a > span")
	WebElement checkoutbtn;
	@FindBy(xpath="//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a/span[1]")
	WebElement carttext;
	
	
	selenumsteps selenium;
	public addtocartpage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		selenium = new selenumsteps();
	}
	public boolean validateaddtocart(WebDriver driver) {
		selenium.performousehover(itemimage, driver);
		selenium.click(btnmore);
		selenium.clear(quantity);
		selenium.SetText("3", quantity);
		selenium.selectbyvisibletext(size, "M");
		selenium.click(addtocartbtn);
		selenium.clickUsingJavaScriptExecutor(checkoutbtn, driver);
		selenium.refresh(driver);
		return selenium.validatetext(driver, carttext, "3");
	}
}
