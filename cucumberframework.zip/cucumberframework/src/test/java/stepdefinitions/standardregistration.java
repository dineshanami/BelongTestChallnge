package stepdefinitions;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
//import javafx.scene.control.RadioButton;

public class standardregistration {

	private WebDriver driver;
	//private Actions action;

	@Given("^I open a browser$")
	public void i_open_a_browser() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C://Users//Lalita//Desktop//Test Automation//Softwares//chromedriver_win32//chromedriver.exe");
		driver = new ChromeDriver();

			}

	@When("^I visit the home page$")
	public void i_visit_the_home_page() throws Throwable {
		driver.get(" http://automationpractice.com/");
		driver.manage().window().maximize();

	}

	@When("^I click on the Sign in button$")
	public void i_click_on_the_Sign_in_button() throws Throwable {
		WebElement login = driver.findElement(By.className("login"));
		login.click();
	}

	@Given("^I land on the authetication page$")
	public void i_land_on_the_authetication_page() throws Throwable {
		System.out.println("landed on authentication page");
	}

	@Given("^I enter my email address$")
	public void i_enter_my_email_address() throws Throwable {
		WebElement email = driver.findElement(By.id("email_create"));
		email.sendKeys("hono@appmail25.com");
	}

	@Given("^I click on the Create an account button$")
	public void i_click_on_the_Create_an_account_button() throws Throwable {
		WebElement nxtBtn = driver.findElement(By.id("SubmitCreate"));
		nxtBtn.click();
		Thread.sleep(3000);
	}

	@When("I select radio button as per the need$")
	public void i_am_at_personal_information_section() throws Throwable {
		// WebElement radio1 = driver.findElement(By.id("id_gender1"));

		driver.findElement(By.id("id_gender1")).click();
		Thread.sleep(3000);
		
	}

	@When("^I enter firstname$")
	public void i_enter_firstname() throws Throwable {
		WebElement firstname = driver.findElement(By.id("customer_firstname"));
		firstname.sendKeys("dinesh");
	}

	@When("^I enter lastname$")
	public void i_enter_lastname() throws Throwable {
		WebElement lastname = driver.findElement(By.id("customer_lastname"));
		lastname.sendKeys("anami");
	}

	@When("^I validate email address entered$")
	public void i_enter_email_address() throws Throwable {
		Thread.sleep(3000);
		
	}

	@When("^I enter the password$")
	public void i_enter_password() throws Throwable {
		WebElement password = driver.findElement(By.id("passwd"));
		password.sendKeys("Master123");
		Thread.sleep(3000);
	}

	@Given("^I select date of birth$")
	public void i_select_date_of_birth() throws Throwable {

		WebElement DaysBtn = driver.findElement(By.id("uniform-days"));
		DaysBtn.click();
		Thread.sleep(1000);
		WebElement Days = driver.findElement(By.id("days"));
		Select dd = new Select(Days);
		dd.selectByIndex(1);
		Thread.sleep(1000);
		WebElement MonthBtn = driver.findElement(By.id("uniform-months"));
		MonthBtn.click();
		Thread.sleep(1000);
		WebElement Month = driver.findElement(By.id("months"));
		Select mm = new Select(Month);
		mm.selectByIndex(3);
		Thread.sleep(1000);
		WebElement YearBtn = driver.findElement(By.id("uniform-years"));
		YearBtn.click();
		Thread.sleep(1000);
		WebElement Year = driver.findElement(By.id("years"));
		Select yy = new Select(Year);
		yy.selectByValue("2000");
		Thread.sleep(1000);
	}

	@When("^I am in address section$")
	public void i_am_in_address_section() throws Throwable {
		WebElement firstnamea = driver.findElement(By.id("firstname"));
		firstnamea.sendKeys("dinesh");
		WebElement lastnamea = driver.findElement(By.id("lastname"));
		lastnamea.sendKeys("anami");
	}

	@When("^I enter company name$")
	public void i_enter_company_name() throws Throwable {
		WebElement companyname = driver.findElement(By.id("company"));
		companyname.sendKeys("ASG");
	}

	@When("^I enter Address line(\\d+)$")
	public void i_enter_Address_line(int arg1) throws Throwable {
		WebElement Address1 = driver.findElement(By.id("address1"));
		Address1.sendKeys("14 Brittle Street");
		WebElement Address2 = driver.findElement(By.id("address2"));
		Address2.sendKeys("Manor Lakes");
	}

	@When("^I enter city$")
	public void i_enter_city() throws Throwable {
		WebElement City = driver.findElement(By.id("city"));
		City.sendKeys("Melbourne");
	}

	@When("^I select state$")
	public void i_select_state() throws Throwable {
		WebElement State = driver.findElement(By.id("id_state"));
		Select St = new Select(State);
		St.selectByVisibleText("Texas");
	}

	@When("^I enter ZIP/postal code$")
	public void i_enter_ZIP_postal_code() throws Throwable {
		WebElement Zip = driver.findElement(By.id("postcode"));
		Zip.sendKeys("78159");
	}

	@When("^I select country$")
	public void i_select_country() throws Throwable {
		WebElement Country = driver.findElement(By.id("id_country"));
		Select CNT = new Select(Country);
		CNT.selectByVisibleText("United States");
	}

	@When("^I enter additional information$")
	public void i_enter_additional_information() throws Throwable {
		WebElement Addnl = driver.findElement(By.id("other"));
		Addnl.sendKeys("IT");
	}

	@When("^I enter home phone number$")
	public void i_enter_home_phone_number() throws Throwable {
		WebElement HPH = driver.findElement(By.id("phone"));
		HPH.sendKeys("8004771477");
	}

	@When("^I enter mobile phone number$")
	public void i_enter_mobile_phone_number() throws Throwable {
		WebElement MPH = driver.findElement(By.id("phone_mobile"));
		MPH.sendKeys("7133137011");
	}

	@When("^I enter alias adress$")
	public void i_enter_alias_adress() throws Throwable {
		WebElement Address3 = driver.findElement(By.id("alias"));
		Address3.sendKeys("12 Brittle Street");
	}

	@When("^I click Register button$")
	public void i_click_Register_button() throws Throwable {
		WebElement RGBtn = driver.findElement(By.id("submitAccount"));
		RGBtn.click();
	}

	@Then("^I should see my account page$")
	public void i_should_see_my_account_page() throws Throwable {
		System.out.println("Welcome to my account page");
	}
	
	@When("^I am at my account page$")
	public void i_am_at_my_account_page() throws Throwable {
		
		Actions action = new Actions(driver);
		WebElement btn = driver.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[2]/a"));
		action.moveToElement(btn).perform();
						
		System.out.println("I am under Summer Dresses Section");
	}

}
