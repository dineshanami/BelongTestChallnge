package paramatisationmaven;

import org.junit.Test;

public class Passingparameterstomaven {
	@Test
	public void f() {
		String valuefrommaven = System.getProperty("PropertyName");
		System.out.println(valuefrommaven);
	}

}
