package seleniumexecution;


	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	//import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.Select;

	//import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;

	public class selenumsteps {	
		Actions action;
		
		public void performousehover(WebElement element, WebDriver driver) {
			action = new Actions(driver);
			action.moveToElement(element).build().perform();		
		}
		
		public void click(WebElement element) {
			element.click();
		}
		
		public void clear(WebElement element) {
			element.clear();
				}
		public void SetText(String text, WebElement element) {
			element.sendKeys(text);
			
		}
		public void selectbyvisibletext(WebElement selectsize,String text) {
			Select s = new Select(selectsize);
			s.selectByVisibleText(text);
		}
		public void clickUsingJavaScriptExecutor (WebElement element, WebDriver driver) {
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();",element);
		}
		public void refresh(WebDriver driver) {
			driver.navigate().refresh();
		}
		public boolean validatetext(WebDriver driver, WebElement element, String ExpectedText) {
			String observedText = element.getText();
			System.out.println(observedText);
			if(observedText.equals(ExpectedText)) {
				return true;}
			
			return false;
		}
	 }

