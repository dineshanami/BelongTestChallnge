package websitetesting;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import websitepages.addtocartpage;

public class addcarttesting {
	WebDriver driver;
	addtocartpage page;
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver",
				"C://Users//Lalita//Desktop//Test Automation//Softwares//chromedriver_win32//chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(" http://automationpractice.com/index.php");
		driver.manage().window().maximize();
		
		page=new addtocartpage(driver);
	}
	@Test
	public void validateaddtocart() {
		Assert.assertTrue(page.validateaddtocart(driver));
	}

}
